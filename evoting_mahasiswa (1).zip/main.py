
from data.pemilih import tambah_pemilih
from data.calon import tambah_calon
from voting.voting import proses_voting
from hasil.hasil_sementara import tampilkan_hasil_sementara
from hasil.statistik import tampilkan_statistik

def menu():
    print("""
    1. Tambah Pemilih
    2. Tambah Calon
    3. Lakukan Voting
    4. Tampilkan Hasil Sementara
    5. Tampilkan Statistik
    0. Keluar
    """)

def main():
    while True:
        menu()
        pilihan = input("Pilih menu: ")
        if pilihan == '1':
            id_p = input("ID Pemilih: ")
            nama = input("Nama: ")
            jurusan = input("Jurusan: ")
            tambah_pemilih(id_p, nama, jurusan)
        elif pilihan == '2':
            id_c = input("ID Calon: ")
            nama = input("Nama: ")
            visi = input("Visi & Misi: ")
            tambah_calon(id_c, nama, visi)
        elif pilihan == '3':
            id_p = input("ID Pemilih: ")
            id_c = input("ID Calon: ")
            proses_voting(id_p, id_c)
        elif pilihan == '4':
            tampilkan_hasil_sementara()
        elif pilihan == '5':
            tampilkan_statistik()
        elif pilihan == '0':
            break
        else:
            print("Menu tidak valid!")

if __name__ == "__main__":
    main()
