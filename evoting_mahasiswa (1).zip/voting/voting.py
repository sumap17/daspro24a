
from data.pemilih import cari_pemilih
from data.calon import cari_calon

def proses_voting(id_pemilih, id_calon):
    pemilih = cari_pemilih(id_pemilih)
    calon = cari_calon(id_calon)

    if not pemilih:
        print("ID pemilih tidak ditemukan.")
        return
    if pemilih["sudah_memilih"]:
        print("Pemilih sudah menggunakan hak pilih.")
        return
    if not calon:
        print("ID calon tidak ditemukan.")
        return

    calon["jumlah_suara"] += 1
    pemilih["sudah_memilih"] = True
    print("Voting berhasil.")
