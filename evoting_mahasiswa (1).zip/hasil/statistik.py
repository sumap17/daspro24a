
from data.pemilih import pemilih_list
from data.calon import calon_list

def tampilkan_statistik():
    total = len(pemilih_list)
    sudah_memilih = sum(1 for p in pemilih_list if p["sudah_memilih"])
    persentase = (sudah_memilih / total * 100) if total > 0 else 0
    if calon_list:
        pemenang = max(calon_list, key=lambda c: c['jumlah_suara'])
    else:
        pemenang = None

    print("\nStatistik Pemilu:")
    print(f"Total Pemilih: {total}")
    print(f"Sudah Memilih: {sudah_memilih}")
    print(f"Persentase Partisipasi: {persentase:.2f}%")
    if pemenang:
        print(f"Pemenang sementara: {pemenang['nama']} ({pemenang['jumlah_suara']} suara)")
