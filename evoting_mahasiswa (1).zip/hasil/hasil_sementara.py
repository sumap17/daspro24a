
from data.calon import calon_list

def tampilkan_hasil_sementara():
    print("\nHasil Sementara:")
    for c in calon_list:
        print(f"{c['nama']} ({c['id']}): {c['jumlah_suara']} suara")
