
pemilih_list = []

def tambah_pemilih(id_pemilih, nama, jurusan):
    if any(p['id'] == id_pemilih for p in pemilih_list):
        print("ID pemilih sudah ada!")
        return
    pemilih_list.append({
        "id": id_pemilih,
        "nama": nama,
        "jurusan": jurusan,
        "sudah_memilih": False
    })

def cari_pemilih(id_pemilih):
    return next((p for p in pemilih_list if p['id'] == id_pemilih), None)
