
calon_list = []

def tambah_calon(id_calon, nama, visi):
    if any(c['id'] == id_calon for c in calon_list):
        print("ID calon sudah ada!")
        return
    calon_list.append({
        "id": id_calon,
        "nama": nama,
        "visi": visi,
        "jumlah_suara": 0
    })

def cari_calon(id_calon):
    return next((c for c in calon_list if c['id'] == id_calon), None)
