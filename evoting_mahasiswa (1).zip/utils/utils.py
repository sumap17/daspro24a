
def input_valid(prompt, valid_list):
    while True:
        val = input(prompt)
        if val in valid_list:
            return val
        print("Input tidak valid, coba lagi.")
